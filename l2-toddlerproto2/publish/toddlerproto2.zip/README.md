## babyproto2

A step further = A better world.

This the next level of babyproto1. In this level, you are required to `exploit` the prototype pollution vulnerability in order to escalate the consequence from DoS to something more exciting like Remote Code Execution (RCE).

I heard someone says that Template Engines are useful to create custom web pages. It should be safe, isn't? Wired, I found the following issue sounds really scary!
https://github.com/squirrellyjs/squirrelly/issues/233



