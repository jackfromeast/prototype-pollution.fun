## babyproto2

Welcome to the world of pollution!

> Like all pollution, prototype pollution leads to real problems!

This is the revenge from babyproto2 challenge. The admin noticed the vulnerability and patched the gadgets using 'defaultFilter' (shown in defaultFilter.patch), can you find more like this?

In this level, you are required to `exploit` the prototype pollution vulnerability in order to escalate the consequence from DoS to something more exciting like Remote Code Execution (RCE). But no more `1-day` gadgets can be leveraged this time.


