#!/usr/bin/bash

while true; do
  node /home/user/app.js
done