#!/usr/bin/bash

while true; do
  node /home/user/admin-bot.js
done